<?php
/**
 * ПОЛНОЕ ТЕСТИРОВАНИЕ ВСЕХ РОЛЕЙ И МЕХАНИК
 * Проверяет распределение, ночные действия, условия победы
 */

require_once 'Game.php';

echo "╔══════════════════════════════════════════════════════════════════╗\n";
echo "║   ПОЛНОЕ ТЕСТИРОВАНИЕ СИСТЕМЫ РОЛЕЙ МАФИИ                       ║\n";
echo "╚══════════════════════════════════════════════════════════════════╝\n\n";

// Определяем ожидаемое распределение для каждого количества игроков
$expectedDistributions = [
    4 => [
        'don' => 1,
        'mafia' => 1,
        'detective' => 1,
        'doctor' => 1
    ],
    5 => [
        'don' => 1,
        'mafia' => 1,
        'detective' => 1,
        'doctor' => 1,
        'citizen' => 1
    ],
    6 => [
        'don' => 1,
        'mafia' => 1,
        'detective' => 1,
        'doctor' => 1,
        'lucky' => 1,
        'citizen' => 1
    ],
    7 => [
        'don' => 1,
        'mafia' => 1,
        'detective' => 1,
        'doctor' => 1,
        'homeless' => 1,
        'kamikaze' => 1,
        'lucky' => 1
    ],
    8 => [
        'don' => 1,
        'mafia' => 1,
        'detective' => 1,
        'doctor' => 1,
        'homeless' => 1,
        'kamikaze' => 1,
        'suicide' => 1,
        'citizen' => 1
    ],
    9 => [
        'don' => 1,
        'mafia' => 2,
        'detective' => 1,
        'doctor' => 1,
        'homeless' => 1,
        'kamikaze' => 1,
        'suicide' => 1,
        'maniac' => 1
    ],
    10 => [
        'don' => 1,
        'mafia' => 2,
        'detective' => 1,
        'doctor' => 1,
        'homeless' => 1,
        'kamikaze' => 1,
        'suicide' => 1,
        'maniac' => 1,
        'lawyer' => 1
    ],
    11 => [
        'don' => 1,
        'mafia' => 2,
        'detective' => 1,
        'doctor' => 1,
        'homeless' => 1,
        'kamikaze' => 1,
        'suicide' => 1,
        'maniac' => 1,
        'lawyer' => 1,
        'lucky' => 1
    ],
    12 => [
        'don' => 1,
        'mafia' => 3,
        'detective' => 1,
        'doctor' => 1,
        'homeless' => 1,
        'kamikaze' => 1,
        'suicide' => 1,
        'maniac' => 1,
        'lawyer' => 1,
        'lucky' => 1
    ]
];

$roleNames = [
    'mafia' => '🔪 Мафия',
    'don' => '🎩 Дон',
    'citizen' => '👤 Мирный житель',
    'detective' => '🔍 Комиссар',
    'doctor' => '💊 Доктор',
    'homeless' => '🏚 Бомж',
    'lover' => '💋 Любовница',
    'maniac' => '🔪 Маньяк',
    'lawyer' => '⚖️ Адвокат',
    'suicide' => '💀 Самоубийца',
    'lucky' => '🍀 Счастливчик',
    'kamikaze' => '💣 Камикадзе'
];

$totalTests = 0;
$passedTests = 0;
$failedTests = [];

// Тестируем каждое количество игроков от 4 до 12
for ($playerCount = 4; $playerCount <= 12; $playerCount++) {
    echo "┌─────────────────────────────────────────────────────────────────┐\n";
    echo "│ ТЕСТ: {$playerCount} игроков" . str_repeat(' ', 53 - strlen("{$playerCount}")) . "│\n";
    echo "└─────────────────────────────────────────────────────────────────┘\n";
    
    // Создаем игру
    $game = new Game(-1001234567890, 'test_' . $playerCount);
    
    // Добавляем игроков
    for ($i = 1; $i <= $playerCount; $i++) {
        $game->addPlayer(
            1000 + $i,
            "Игрок",
            "$i",
            "player$i"
        );
    }
    
    // Запускаем игру (происходит распределение ролей)
    $game->startGame();
    
    // Собираем фактическое распределение
    $actualDistribution = [];
    foreach ($game->getPlayers() as $player) {
        $role = $player['role'];
        if (!isset($actualDistribution[$role])) {
            $actualDistribution[$role] = 0;
        }
        $actualDistribution[$role]++;
    }
    
    // Выводим распределение
    echo "Распределение ролей:\n";
    $totalRoles = 0;
    foreach ($actualDistribution as $role => $count) {
        $roleName = $roleNames[$role] ?? "❓ $role";
        echo "  {$roleName}: {$count}\n";
        $totalRoles += $count;
    }
    echo "\nВсего ролей: {$totalRoles}\n";
    
    // Проверяем соответствие ожиданиям
    $expected = $expectedDistributions[$playerCount];
    $errors = [];
    
    // ТЕСТ 1: Общее количество ролей
    $totalTests++;
    if ($totalRoles !== $playerCount) {
        $errors[] = "❌ КРИТИЧЕСКАЯ ОШИБКА: Распределено {$totalRoles} ролей вместо {$playerCount}!";
        $failedTests[] = "Игроков {$playerCount}: неверное общее количество ролей";
    } else {
        $passedTests++;
    }
    
    // ТЕСТ 2: Соответствие ожидаемому распределению
    foreach ($expected as $role => $expectedCount) {
        $totalTests++;
        $actualCount = $actualDistribution[$role] ?? 0;
        if ($actualCount !== $expectedCount) {
            $roleName = $roleNames[$role] ?? $role;
            $errors[] = "❌ ОШИБКА: {$roleName} - ожидалось {$expectedCount}, получено {$actualCount}!";
            $failedTests[] = "Игроков {$playerCount}: неверное количество роли {$role}";
        } else {
            $passedTests++;
        }
    }
    
    // ТЕСТ 3: Нет неожиданных ролей
    foreach ($actualDistribution as $role => $count) {
        if (!isset($expected[$role])) {
            $totalTests++;
            $roleName = $roleNames[$role] ?? $role;
            $errors[] = "❌ ОШИБКА: Неожиданная роль {$roleName} (не должна появляться при {$playerCount} игроках)!";
            $failedTests[] = "Игроков {$playerCount}: неожиданная роль {$role}";
        }
    }
    
    // ТЕСТ 4: Минимум 2 мафиози
    $totalTests++;
    $mafiaTotal = ($actualDistribution['don'] ?? 0) + ($actualDistribution['mafia'] ?? 0);
    if ($mafiaTotal < 2) {
        $errors[] = "❌ КРИТИЧЕСКАЯ ОШИБКА: Всего {$mafiaTotal} мафиози вместо минимум 2!";
        $failedTests[] = "Игроков {$playerCount}: недостаточно мафиози";
    } else {
        $passedTests++;
    }
    
    // ТЕСТ 5: Проверка квоты мафии
    $totalTests++;
    $expectedMafiaQuota = (int)max(2, floor($playerCount / 3)); // Приводим к int для корректного сравнения
    if ($mafiaTotal != $expectedMafiaQuota) { // Используем != вместо !== для сравнения чисел
        $errors[] = "❌ КРИТИЧЕСКАЯ ОШИБКА: Квота мафии {$mafiaTotal}, ожидалось {$expectedMafiaQuota} (формула: max(2, floor({$playerCount}/3)))";
        $failedTests[] = "Игроков {$playerCount}: неверная квота мафии ({$mafiaTotal} вместо {$expectedMafiaQuota})";
    } else {
        $passedTests++;
        echo "✓ Квота мафии корректна: {$mafiaTotal} (формула: max(2, floor({$playerCount}/3)))\n";
    }
    
    // ТЕСТ 6: Роль Lover НЕ должна появляться
    $totalTests++;
    if (isset($actualDistribution['lover'])) {
        $errors[] = "❌ ОШИБКА: Роль Любовница не должна распределяться!";
        $failedTests[] = "Игроков {$playerCount}: Lover распределена (не должна быть)";
    } else {
        $passedTests++;
    }
    
    // Выводим результаты проверки
    echo "\n";
    if (empty($errors)) {
        echo "✅ ВСЕ ПРОВЕРКИ ПРОЙДЕНЫ!\n";
    } else {
        foreach ($errors as $error) {
            echo "$error\n";
        }
    }
    
    echo "\n";
}

// Итоговая статистика
echo "╔══════════════════════════════════════════════════════════════════╗\n";
echo "║   ИТОГОВЫЕ РЕЗУЛЬТАТЫ ТЕСТИРОВАНИЯ                              ║\n";
echo "╚══════════════════════════════════════════════════════════════════╝\n\n";

echo "Всего тестов: {$totalTests}\n";
echo "Пройдено: {$passedTests}\n";
echo "Провалено: " . ($totalTests - $passedTests) . "\n";

if ($totalTests === $passedTests) {
    echo "\n🎉 ВСЕ ТЕСТЫ УСПЕШНО ПРОЙДЕНЫ!\n";
    echo "Система распределения ролей работает БЕЗУПРЕЧНО!\n";
} else {
    echo "\n⚠️ ОБНАРУЖЕНЫ ОШИБКИ:\n";
    foreach ($failedTests as $i => $error) {
        echo ($i + 1) . ". {$error}\n";
    }
}

echo "\n";
echo "═══════════════════════════════════════════════════════════════════\n";
