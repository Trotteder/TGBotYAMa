#!/bin/bash
php timer_checker.php &
